import {Component, OnInit} from "@angular/core";
import {DataService} from "./services/data.service";

@Component({
  selector:'head-component',
  templateUrl:'./head.component.html',
  styleUrls:['./head.component.css']
})

export class HeadComponent implements  OnInit{
  title1='Inventory';
  title2='Management';
  public isLogged:boolean=false;
  constructor(private  dataService:DataService){}

  ngOnInit(){
   /* this.isLogged=this.dataService.isLogged;
    console.log(this.isLogged,this.dataService.isLogged,this.dataService.loggedUser);*/
  console.log(this.loggedUser);

}
  public  loggedUser:string=this.dataService.loggedUser;
}
