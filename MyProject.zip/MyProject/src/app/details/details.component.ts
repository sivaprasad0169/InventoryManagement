import {Component,OnInit} from "@angular/core";
import {InventoryItemsService} from "../services/inventory-items.service";


@Component({
  templateUrl:'./details.component.html',
  styleUrls:['../seach.component.css']
})
export class DetailsComponent implements OnInit{
  title='DetailsComponent';
  public itemsDetails=[];
  getError:string=null;

  constructor(private inventoryItems:InventoryItemsService){}

  ngOnInit(){
    this.inventoryItems.getAllInventoryItems()
      .subscribe(responseData=>this.itemsDetails=responseData,
        resError=>this.getError=resError);
    console.log(this.getError);


  }
  SeachText(value1,value2){
    console.log(value1,value2);
    console.log("Working");
    this.inventoryItems.getInventoryItemsBySort(value1,value2)
      .subscribe(resEmployeeData=>this.itemsDetails=resEmployeeData,
        resEmployeeError=>this.getError=resEmployeeError);
  }
}
