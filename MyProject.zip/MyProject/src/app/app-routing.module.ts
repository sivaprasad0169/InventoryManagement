import {NgModule} from "@angular/core";
import {RouterModule,Routes} from "@angular/router";

import {UpdateComponent} from "./update/update.component";
import {DetailsComponent} from "./details/details.component";
import {RegistrationComponent} from "./register/registration.component";
import {TestComponent} from "./login/test.component";
import {AvailabeItemsComponent} from "./available/availabe-items.component";
import {HomeComponent} from "./home/home.component";
import {UpdateItemComponent} from "./update/update-item.component";

const routes:Routes=[
  {path: '', redirectTo: 'login', pathMatch: 'full'},
  {path:'home',component:HomeComponent},
  {path:'update',component:UpdateComponent},
  {path:'available',component:AvailabeItemsComponent},
  {path:'details',component:DetailsComponent},
  {path:'login',component:TestComponent},
  {path:'register',component:RegistrationComponent},
  {path:'update/:id',component:UpdateItemComponent}

];
@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]
})
export class AppRoutingModule{}
/*export const routingComponents=[TestComponent,RegistrationComponent,HomeComponent,UpdateComponent,AvailabeItemsComponent,DetailsComponent];*/
