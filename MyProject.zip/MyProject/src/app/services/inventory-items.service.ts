import {Injectable} from "@angular/core";
import {Http,Response} from "@angular/http";
import {Observable} from "rxjs/Observable";
import {Headers} from "@angular/http"
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()

export class InventoryItemsService {

  private _urlget: string = "http://localhost:8080/inventory/InventoryItems/get";
  private _urlgetBysort="http://localhost:8080/inventory/InventoryItems/getItemsBySortingAndSearching";

  constructor(private _http: Http) {
  }


  getAllInventoryItems()
  {


    return this._http.get(this._urlget).map((response: Response) => response.json())
      .catch(this._catchError);

  }

  _catchError(error: Response)
  {
    return Observable.throw(error || 'server Error');
  }

  getInventoryItemsBySort(text,sortBy){

    let postData={"searchText":text,"sortBy":sortBy}

    var headers=new Headers();
    headers.append('Content-Type',
      'application/json');

    return this._http.post(this._urlgetBysort,postData)
      .map((res:Response)=>res.json());

  }
}
