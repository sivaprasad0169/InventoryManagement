import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {BodyComponent} from "../body.component";


@NgModule({
  declarations: [BodyComponent],
  imports: [CommonModule],
  providers: [],
  bootstrap: [],
  exports: [BodyComponent]
})
export class BodyModule { }
