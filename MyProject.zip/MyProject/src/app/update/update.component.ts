import {Component,OnInit} from "@angular/core";
import { UpdateService} from "./UpdateService"
import {Router} from "@angular/router";
import {InventoryItemsService} from "../services/inventory-items.service";

@Component({
  templateUrl:'./update.component.html',
  styleUrls:['../details/details.component.css']
})

export class UpdateComponent implements OnInit{
  errorMsg:string;
  public items=[];

  constructor(private updateService:UpdateService,private router:Router,private inventoryItems:InventoryItemsService){}

  ngOnInit(){

    this.updateService.getAllItems()
      .subscribe(resEmployeeData=>this.items=resEmployeeData,
        resEmployeeError=>this.errorMsg=resEmployeeError);
  }


  onClick(item)
  {
    this.router.navigate(['update',item.itemId]);
  }


  SeachText(value1,value2){
    console.log(value1,value2);
    console.log("Working");
    this.inventoryItems.getInventoryItemsBySort(value1,value2)
      .subscribe(resEmployeeData=>this.items=resEmployeeData,
        resEmployeeError=>this.errorMsg=resEmployeeError);
  }
}
