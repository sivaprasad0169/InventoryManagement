import {Component,OnInit} from "@angular/core";
import { UpdateService} from "./UpdateService"
import {ActivatedRoute,Router} from "@angular/router";
import {Params} from "@angular/router"

@Component({
  selector:'employee-details',
  templateUrl:'./update-item.component.html',
  styleUrls:['./update-item.component.css']
})

export class UpdateItemComponent implements OnInit{

  public itemId;
  errorMsg:string;
  public items=[];
  constructor(private updateService:UpdateService,private route:ActivatedRoute,private router:Router){}

  ngOnInit(){
    this.updateService.getAllItems().subscribe(resEmployeeData=>this.items=resEmployeeData,
      resEmployeeError=>this.errorMsg=resEmployeeError);

    let id=this.route.snapshot.params['id'];
    this.itemId=id;

  }
  clicking(value:any,id){
    console.log(value);
  }

}
