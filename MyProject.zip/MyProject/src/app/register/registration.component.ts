import {Component} from "@angular/core";
import {DataService} from "../services/data.service";
import {LoginService} from "../services/login-service";
import {RegisterService} from "../services/register.service";
import {Router} from "@angular/router";





@Component({
  selector:'reg-component',
  templateUrl:'./registration.component.html',
  styleUrls: ['./registration.component.css']

})

export class RegistrationComponent{

  public errorMsg:string;
  public postError:string;

  constructor(private  dataService:DataService,private registerService:RegisterService,private router:Router){}
  on(uname,pwd,fname,lname){
    console.log(this.dataService.loggedUser);

    this.registerService.postUserRegistrationData(uname,pwd,fname,lname)
      .subscribe(data => {
          if ( data !== 0)
          {
            this.router.navigate(['/home']);
            alert("You have Successfullt Registered ");

          }
          else
          {
            this.errorMsg="Unable Register Your Details !";
          }
        },
        dataError => this.postError = dataError);



  }


}

